import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { sounds } from '../../logic/audio';
import { Card, Suit, Rank, RANK_LABELS } from '../../logic/poker';
import { CardView } from '../../components/CardView';
import { UserProfile } from '../../logic/auth';
import { TienLenRoom } from '../../components/TienLenRoomModal';

interface TienLenGameProps {
  currentUser: UserProfile | null;
  onUpdateChips: (newChips: number, wonAmount: number) => void;
  onExit: () => void;
  onRequireRegister: () => void;
  roomConfig?: TienLenRoom | null;
}

// Tien Len Rank Value: 3 is lowest (3), 2 is highest (15)
export function getTienLenRankValue(rank: Rank): number {
  if (rank === 2) return 15;
  return rank;
}

// Tien Len Suit Value: Spades (1) < Clubs (2) < Diamonds (3) < Hearts (4)
export function getTienLenSuitValue(suit: Suit): number {
  switch (suit) {
    case 'spades': return 1;
    case 'clubs': return 2;
    case 'diamonds': return 3;
    case 'hearts': return 4;
  }
}

// Compare two single cards in Tien Len
export function compareTienLenCards(a: Card, b: Card): number {
  const rankDiff = getTienLenRankValue(a.rank) - getTienLenRankValue(b.rank);
  if (rankDiff !== 0) return rankDiff;
  return getTienLenSuitValue(a.suit) - getTienLenSuitValue(b.suit);
}

// Combination Types
export type ComboType =
  | 'SINGLE'
  | 'PAIR'
  | 'TRIPLE'
  | 'STRAIGHT'
  | 'FOUR_OF_A_KIND'
  | 'THREE_PAIRS_SEQ'
  | 'FOUR_PAIRS_SEQ'
  | 'INVALID';

export interface EvaluatedPlay {
  type: ComboType;
  cards: Card[];
  highestCard: Card;
  length: number;
}

export function getTienLenPlayNameVi(play: EvaluatedPlay): string {
  if (play.type === 'SINGLE') {
    const isHeo = play.highestCard.rank === 2;
    return isHeo ? 'Lá Heo (2)' : `Lá lẻ ${RANK_LABELS[play.highestCard.rank]}`;
  }
  if (play.type === 'PAIR') {
    const isHeo = play.highestCard.rank === 2;
    return isHeo ? 'Đôi Heo (2)' : `Đôi ${RANK_LABELS[play.highestCard.rank]}`;
  }
  if (play.type === 'TRIPLE') {
    return `Sám cô ${RANK_LABELS[play.highestCard.rank]}`;
  }
  if (play.type === 'FOUR_OF_A_KIND') {
    return `💥 TỨ QUÝ ${RANK_LABELS[play.highestCard.rank]}!`;
  }
  if (play.type === 'STRAIGHT') {
    return `Sảnh ${play.length} lá (tới ${RANK_LABELS[play.highestCard.rank]})`;
  }
  if (play.type === 'THREE_PAIRS_SEQ') {
    return `🔥 3 ĐÔI THÔNG!`;
  }
  if (play.type === 'FOUR_PAIRS_SEQ') {
    return `⚡ 4 ĐÔI THÔNG!`;
  }
  return 'Bài Đánh';
}

// Evaluate a set of selected cards
export function evaluateTienLenPlay(cards: Card[]): EvaluatedPlay {
  if (cards.length === 0) {
    return { type: 'INVALID', cards: [], highestCard: cards[0], length: 0 };
  }

  const sorted = [...cards].sort(compareTienLenCards);
  const highest = sorted[sorted.length - 1];
  const count = sorted.length;

  // Single
  if (count === 1) {
    return { type: 'SINGLE', cards: sorted, highestCard: highest, length: 1 };
  }

  // Pair
  if (count === 2 && sorted[0].rank === sorted[1].rank) {
    return { type: 'PAIR', cards: sorted, highestCard: highest, length: 2 };
  }

  // Triple
  if (count === 3 && sorted[0].rank === sorted[1].rank && sorted[1].rank === sorted[2].rank) {
    return { type: 'TRIPLE', cards: sorted, highestCard: highest, length: 3 };
  }

  // Four of a kind (Tứ Quý)
  if (count === 4 && sorted.every((c) => c.rank === sorted[0].rank)) {
    return { type: 'FOUR_OF_A_KIND', cards: sorted, highestCard: highest, length: 4 };
  }

  // Check Straight (Sảnh: >= 3 cards, consecutive ranks, NO 2 allowed)
  if (count >= 3 && sorted.every((c) => c.rank !== 2)) {
    let isStraight = true;
    for (let i = 0; i < count - 1; i++) {
      if (getTienLenRankValue(sorted[i + 1].rank) - getTienLenRankValue(sorted[i].rank) !== 1) {
        isStraight = false;
        break;
      }
    }
    if (isStraight) {
      return { type: 'STRAIGHT', cards: sorted, highestCard: highest, length: count };
    }
  }

  // Check 3 consecutive pairs (3 đôi thông: 6 cards)
  if (count === 6 && sorted.every((c) => c.rank !== 2)) {
    if (
      sorted[0].rank === sorted[1].rank &&
      sorted[2].rank === sorted[3].rank &&
      sorted[4].rank === sorted[5].rank &&
      getTienLenRankValue(sorted[2].rank) - getTienLenRankValue(sorted[0].rank) === 1 &&
      getTienLenRankValue(sorted[4].rank) - getTienLenRankValue(sorted[2].rank) === 1
    ) {
      return { type: 'THREE_PAIRS_SEQ', cards: sorted, highestCard: highest, length: 6 };
    }
  }

  // Check 4 consecutive pairs (4 đôi thông: 8 cards)
  if (count === 8 && sorted.every((c) => c.rank !== 2)) {
    if (
      sorted[0].rank === sorted[1].rank &&
      sorted[2].rank === sorted[3].rank &&
      sorted[4].rank === sorted[5].rank &&
      sorted[6].rank === sorted[7].rank &&
      getTienLenRankValue(sorted[2].rank) - getTienLenRankValue(sorted[0].rank) === 1 &&
      getTienLenRankValue(sorted[4].rank) - getTienLenRankValue(sorted[2].rank) === 1 &&
      getTienLenRankValue(sorted[6].rank) - getTienLenRankValue(sorted[4].rank) === 1
    ) {
      return { type: 'FOUR_PAIRS_SEQ', cards: sorted, highestCard: highest, length: 8 };
    }
  }

  return { type: 'INVALID', cards: sorted, highestCard: highest, length: count };
}

// Check if Play A can beat Play B
export function canBeatTienLen(prevPlay: EvaluatedPlay | null, newPlay: EvaluatedPlay): boolean {
  if (newPlay.type === 'INVALID') return false;
  if (!prevPlay) return true; // Leading trick can play any valid combo

  // Chặt Heo logic
  const isTargetHeo = prevPlay.type === 'SINGLE' && prevPlay.highestCard.rank === 2;
  const isTargetPairHeo = prevPlay.type === 'PAIR' && prevPlay.highestCard.rank === 2;

  // 3 đôi thông chặt được 1 Heo hoặc 3 đôi thông nhỏ hơn
  if (newPlay.type === 'THREE_PAIRS_SEQ') {
    if (isTargetHeo) return true;
    if (prevPlay.type === 'THREE_PAIRS_SEQ') {
      return compareTienLenCards(newPlay.highestCard, prevPlay.highestCard) > 0;
    }
  }

  // Tứ Quý chặt được 1 Heo, đôi Heo, 3 đôi thông, hoặc Tứ Quý nhỏ hơn
  if (newPlay.type === 'FOUR_OF_A_KIND') {
    if (isTargetHeo || isTargetPairHeo || prevPlay.type === 'THREE_PAIRS_SEQ') return true;
    if (prevPlay.type === 'FOUR_OF_A_KIND') {
      return compareTienLenCards(newPlay.highestCard, prevPlay.highestCard) > 0;
    }
  }

  // 4 đôi thông chặt được 1 Heo, đôi Heo, 3 Heo, Tứ Quý, 3 đôi thông, hoặc 4 đôi thông nhỏ hơn
  if (newPlay.type === 'FOUR_PAIRS_SEQ') {
    if (isTargetHeo || isTargetPairHeo || prevPlay.type === 'FOUR_OF_A_KIND' || prevPlay.type === 'THREE_PAIRS_SEQ') {
      return true;
    }
    if (prevPlay.type === 'FOUR_PAIRS_SEQ') {
      return compareTienLenCards(newPlay.highestCard, prevPlay.highestCard) > 0;
    }
  }

  // Standard same-type matching
  if (prevPlay.type === newPlay.type) {
    if (prevPlay.type === 'STRAIGHT') {
      if (prevPlay.length !== newPlay.length) return false;
    }
    return compareTienLenCards(newPlay.highestCard, prevPlay.highestCard) > 0;
  }

  return false;
}

// Find smart suggestion combo for player
export function findSmartHintPlay(handCards: Card[], prevPlay: EvaluatedPlay | null): Card[] | null {
  const sorted = [...handCards].sort(compareTienLenCards);
  if (!prevPlay) {
    // If first trick: check if holds 3 Bich
    const threeSpades = sorted.find((c) => c.rank === 3 && c.suit === 'spades');
    if (threeSpades) return [threeSpades];
    // Otherwise smallest single or pair
    if (sorted.length >= 2 && sorted[0].rank === sorted[1].rank) {
      return [sorted[0], sorted[1]];
    }
    return [sorted[0]];
  }

  // Beat Single
  if (prevPlay.type === 'SINGLE') {
    // Check normal single
    for (const c of sorted) {
      const play = evaluateTienLenPlay([c]);
      if (canBeatTienLen(prevPlay, play)) return [c];
    }
    // Check Chặt Heo with Tứ Quý
    if (prevPlay.highestCard.rank === 2) {
      for (let i = 0; i <= sorted.length - 4; i++) {
        if (sorted[i].rank === sorted[i + 3].rank) {
          return [sorted[i], sorted[i + 1], sorted[i + 2], sorted[i + 3]];
        }
      }
    }
  }

  // Beat Pair
  if (prevPlay.type === 'PAIR') {
    for (let i = 0; i < sorted.length - 1; i++) {
      if (sorted[i].rank === sorted[i + 1].rank) {
        const play = evaluateTienLenPlay([sorted[i], sorted[i + 1]]);
        if (canBeatTienLen(prevPlay, play)) return [sorted[i], sorted[i + 1]];
      }
    }
    // Check Tứ Quý chops pair of 2s
    if (prevPlay.highestCard.rank === 2) {
      for (let i = 0; i <= sorted.length - 4; i++) {
        if (sorted[i].rank === sorted[i + 3].rank) {
          return [sorted[i], sorted[i + 1], sorted[i + 2], sorted[i + 3]];
        }
      }
    }
  }

  // Beat Triple
  if (prevPlay.type === 'TRIPLE') {
    for (let i = 0; i < sorted.length - 2; i++) {
      if (sorted[i].rank === sorted[i + 1].rank && sorted[i + 1].rank === sorted[i + 2].rank) {
        const play = evaluateTienLenPlay([sorted[i], sorted[i + 1], sorted[i + 2]]);
        if (canBeatTienLen(prevPlay, play)) return [sorted[i], sorted[i + 1], sorted[i + 2]];
      }
    }
  }

  return null;
}

export interface PlayerSeat {
  id: string;
  name: string;
  avatarColor: string;
  isHuman: boolean;
  cards: Card[];
  passed: boolean;
  rankFinished?: number;
}

export const TienLenGame: React.FC<TienLenGameProps> = ({
  currentUser,
  onUpdateChips,
  onExit,
  onRequireRegister,
  roomConfig,
}) => {
  const [chips, setChips] = useState<number>(currentUser?.chips || 2500);
  const [stake, setStake] = useState<number>(roomConfig ? roomConfig.stake : 100);
  const [gameState, setGameState] = useState<'IDLE' | 'DEALING' | 'PLAYING' | 'GAME_OVER'>('IDLE');
  const [currentTurnIdx, setCurrentTurnIdx] = useState<number>(0);
  const [lastPlay, setLastPlay] = useState<{ playerIdx: number; play: EvaluatedPlay; angle: number } | null>(null);
  const [selectedCardIds, setSelectedCardIds] = useState<Set<string>>(new Set());
  const [specialEffectText, setSpecialEffectText] = useState<string | null>(null);
  const turnTimeLimit = roomConfig?.turnTimeSeconds || 20;
  const [timerSeconds, setTimerSeconds] = useState<number>(turnTimeLimit);
  const [copyToast, setCopyToast] = useState<string | null>(null);
  const [dealingProgress, setDealingProgress] = useState<number>(0);

  // Initialize 4 players
  const [players, setPlayers] = useState<PlayerSeat[]>(() => {
    if (roomConfig && roomConfig.players && roomConfig.players.length > 0) {
      const heroInRoom = roomConfig.players.find((p) => p.name === currentUser?.name || !p.isBot) || roomConfig.players[0];
      const otherPlayers = roomConfig.players.filter((p) => p.id !== heroInRoom.id);

      const seat0: PlayerSeat = {
        id: heroInRoom.id,
        name: heroInRoom.name,
        avatarColor: heroInRoom.avatarColor || '#f43f5e',
        isHuman: true,
        cards: [],
        passed: false,
      };

      const result: PlayerSeat[] = [seat0];
      const defaultBots = ['Đông Hải', 'Nam Phong', 'Tây Sơn'];
      const defaultColors = ['#10b981', '#3b82f6', '#8b5cf6'];

      for (let i = 0; i < 3; i++) {
        if (otherPlayers[i]) {
          result.push({
            id: otherPlayers[i].id,
            name: otherPlayers[i].name,
            avatarColor: otherPlayers[i].avatarColor || defaultColors[i],
            isHuman: false,
            cards: [],
            passed: false,
          });
        } else {
          result.push({
            id: `bot_${i}`,
            name: defaultBots[i] + ' (AI)',
            avatarColor: defaultColors[i],
            isHuman: false,
            cards: [],
            passed: false,
          });
        }
      }
      return result;
    }

    return [
      { id: 'hero', name: currentUser?.name || 'Bạn', avatarColor: currentUser?.avatarColor || '#f43f5e', isHuman: true, cards: [], passed: false },
      { id: 'bot1', name: 'Đông Hải', avatarColor: '#10b981', isHuman: false, cards: [], passed: false },
      { id: 'bot2', name: 'Nam Phong', avatarColor: '#3b82f6', isHuman: false, cards: [], passed: false },
      { id: 'bot3', name: 'Tây Sơn', avatarColor: '#8b5cf6', isHuman: false, cards: [], passed: false },
    ];
  });

  const [gameAnnouncement, setGameAnnouncement] = useState<string>('');

  // Sync user chips
  useEffect(() => {
    if (currentUser?.chips !== undefined) {
      setChips(currentUser.chips);
    }
  }, [currentUser?.chips]);

  // Trigger special popup effect
  const triggerSpecialBanner = (text: string) => {
    setSpecialEffectText(text);
    sounds.playAllIn();
    setTimeout(() => {
      setSpecialEffectText(null);
    }, 2400);
  };

  // Turn Countdown Timer (15 seconds)
  useEffect(() => {
    if (gameState !== 'PLAYING') return;

    setTimerSeconds(15);
    const interval = setInterval(() => {
      setTimerSeconds((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          // Auto action on timeout
          if (currentTurnIdx === 0) {
            if (lastPlay) {
              handleHeroPass();
            } else if (players[0].cards.length > 0) {
              const lowest = players[0].cards[0];
              executePlayerPlay(0, evaluateTienLenPlay([lowest]));
            }
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [currentTurnIdx, gameState, lastPlay]);

  // Start new game with Cybergame animated dealing sequence
  const startNewTienLen = () => {
    if (!currentUser) {
      onRequireRegister();
      return;
    }

    if (chips < stake * 2) {
      alert('Không đủ chip để tham gia ván đấu!');
      return;
    }

    setGameState('DEALING');
    setGameAnnouncement('Đang chia bài...');
    setDealingProgress(0);

    // Create 52-card deck
    const suits: Suit[] = ['spades', 'clubs', 'diamonds', 'hearts'];
    const ranks: Rank[] = [3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 2];
    const deck: Card[] = [];
    for (const suit of suits) {
      for (const rank of ranks) {
        deck.push({ id: `${rank}_${suit}`, rank, suit });
      }
    }
    // Fisher-Yates Shuffle
    for (let i = deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }

    const p0 = deck.slice(0, 13).sort(compareTienLenCards);
    const p1 = deck.slice(13, 26).sort(compareTienLenCards);
    const p2 = deck.slice(26, 39).sort(compareTienLenCards);
    const p3 = deck.slice(39, 52).sort(compareTienLenCards);

    // Find who has 3 Bích (3 Spades)
    let startingPlayer = 0;
    const hands = [p0, p1, p2, p3];
    for (let i = 0; i < 4; i++) {
      if (hands[i].some((c) => c.rank === 3 && c.suit === 'spades')) {
        startingPlayer = i;
        break;
      }
    }

    // Sound effect ticks for dealing
    sounds.playCardDeal();
    const dealTicker = setInterval(() => {
      sounds.playCardDeal();
      setDealingProgress((prev) => Math.min(100, prev + 25));
    }, 280);

    setTimeout(() => {
      clearInterval(dealTicker);
      setPlayers((prev) => [
        { ...prev[0], cards: p0, passed: false },
        { ...prev[1], cards: p1, passed: false },
        { ...prev[2], cards: p2, passed: false },
        { ...prev[3], cards: p3, passed: false },
      ]);
      setLastPlay(null);
      setSelectedCardIds(new Set());
      setCurrentTurnIdx(startingPlayer);
      setGameState('PLAYING');
      sounds.playChips();
      setGameAnnouncement(
        startingPlayer === 0
          ? 'Lượt của bạn! Bạn sở hữu 3 Bích đi đầu tiên.'
          : `Lượt của ${players[startingPlayer].name} đi đầu tiên!`
      );
    }, 1200);
  };

  // Drag selection state
  const isDraggingRef = useRef<boolean>(false);
  const dragModeRef = useRef<'add' | 'remove'>('add');

  useEffect(() => {
    const handleGlobalMouseUp = () => {
      isDraggingRef.current = false;
    };
    window.addEventListener('mouseup', handleGlobalMouseUp);
    window.addEventListener('touchend', handleGlobalMouseUp);
    return () => {
      window.removeEventListener('mouseup', handleGlobalMouseUp);
      window.removeEventListener('touchend', handleGlobalMouseUp);
    };
  }, []);

  // Card interaction: mouse down starts drag selection
  const handleCardMouseDown = (cardId: string) => {
    isDraggingRef.current = true;
    sounds.playCardLift();
    setSelectedCardIds((prev) => {
      const next = new Set(prev);
      if (next.has(cardId)) {
        next.delete(cardId);
        dragModeRef.current = 'remove';
      } else {
        next.add(cardId);
        dragModeRef.current = 'add';
      }
      return next;
    });
  };

  // Drag over card to swipe-select multiple cards smoothly
  const handleCardMouseEnter = (cardId: string) => {
    if (!isDraggingRef.current) return;
    sounds.playCardLift();
    setSelectedCardIds((prev) => {
      const next = new Set(prev);
      if (dragModeRef.current === 'add') {
        next.add(cardId);
      } else {
        next.delete(cardId);
      }
      return next;
    });
  };

  // Double-click card to auto-select pair / triple / four of a kind
  const handleDoubleClickCard = (card: Card) => {
    sounds.playChips();
    const matchingCards = players[0].cards.filter((c) => c.rank === card.rank);
    if (matchingCards.length > 1) {
      setSelectedCardIds(new Set(matchingCards.map((c) => c.id)));
    } else {
      setSelectedCardIds(new Set([card.id]));
    }
  };

  // Smart Suggestion (GỢI Ý)
  const handleSmartHint = () => {
    if (currentTurnIdx !== 0) return;
    const hintCards = findSmartHintPlay(players[0].cards, lastPlay?.play || null);
    if (hintCards && hintCards.length > 0) {
      sounds.playCardLift();
      setSelectedCardIds(new Set(hintCards.map((c) => c.id)));
    } else {
      sounds.playFold();
      setGameAnnouncement('Không có nước bài nào đè được! Bạn có thể Bỏ Lượt.');
    }
  };

  // Auto Sort Hand
  const handleSortHand = () => {
    sounds.playChips();
    setPlayers((prev) => [
      {
        ...prev[0],
        cards: [...prev[0].cards].sort(compareTienLenCards),
      },
      ...prev.slice(1),
    ]);
  };

  // Deselect All
  const handleDeselectAll = () => {
    sounds.playClick();
    setSelectedCardIds(new Set());
  };

  // Selected play evaluation
  const selectedCardsList = players[0].cards.filter((c) => selectedCardIds.has(c.id));
  const currentSelectedPlay = evaluateTienLenPlay(selectedCardsList);
  const canPlaySelected =
    currentTurnIdx === 0 &&
    currentSelectedPlay.type !== 'INVALID' &&
    canBeatTienLen(lastPlay?.play || null, currentSelectedPlay);

  // Play Selected Cards
  const handleHeroPlayCards = () => {
    if (!canPlaySelected) return;
    executePlayerPlay(0, currentSelectedPlay);
  };

  // Hero Pass turn
  const handleHeroPass = () => {
    if (currentTurnIdx !== 0 || !lastPlay) return;
    sounds.playFold();
    executePlayerPass(0);
  };

  // Execute a play with animations & special effect detection
  const executePlayerPlay = (playerIdx: number, play: EvaluatedPlay) => {
    // Check special "Chặt Heo" or "Tứ Quý" effects
    const isTargetHeo = lastPlay && lastPlay.play.highestCard.rank === 2;
    const isChop = isTargetHeo || play.type === 'FOUR_OF_A_KIND' || play.type === 'THREE_PAIRS_SEQ';

    if (isChop) {
      sounds.playChop();
      if (isTargetHeo) {
        if (play.type === 'FOUR_OF_A_KIND') {
          triggerSpecialBanner(`💥 ${players[playerIdx].name.toUpperCase()} TỨ QUÝ CHẶT HEO! 💥`);
        } else if (play.type === 'THREE_PAIRS_SEQ' || play.type === 'FOUR_PAIRS_SEQ') {
          triggerSpecialBanner(`🔥 ${players[playerIdx].name.toUpperCase()} ĐÔI THÔNG CHẶT HEO! 🔥`);
        } else if (play.highestCard.rank === 2) {
          triggerSpecialBanner(`⚡ ${players[playerIdx].name.toUpperCase()} CHẶT HEO ĐÈ! ⚡`);
        }
      } else if (play.type === 'FOUR_OF_A_KIND') {
        triggerSpecialBanner(`💥 TỨ QUÝ XUẤT TRẬN! 💥`);
      }
    } else {
      sounds.playCardSlap();
      if (play.highestCard.rank === 2) {
        triggerSpecialBanner(`🔥 HEO RA TRẬN! 🔥`);
      }
    }

    const updatedPlayers = [...players];
    const player = updatedPlayers[playerIdx];

    // Remove played cards
    player.cards = player.cards.filter((c) => !play.cards.some((pc) => pc.id === c.id));

    // Random organic angle (-4 to +4 deg)
    const randomAngle = (Math.random() - 0.5) * 8;
    setLastPlay({ playerIdx, play, angle: randomAngle });
    setSelectedCardIds(new Set());

    // Check Win (Tới Nhất)
    if (player.cards.length === 0) {
      setGameState('GAME_OVER');
      if (player.isHuman) {
        sounds.playWin();
        confetti({ particleCount: 220, spread: 100 });
        const wonReward = stake * 4;
        const newTotal = chips + wonReward;
        setChips(newTotal);
        onUpdateChips(newTotal, wonReward);
        triggerSpecialBanner(`👑 BẠN ĐÃ TỚI NHẤT! (+${wonReward.toLocaleString()}) 👑`);
        setGameAnnouncement(`XUẤT SẮC! BẠN ĐÃ TỚI NHẤT VÀ THẮNG +$${wonReward.toLocaleString()}!`);
      } else {
        sounds.playFold();
        const lost = stake * 2;
        const newTotal = Math.max(0, chips - lost);
        setChips(newTotal);
        onUpdateChips(newTotal, -lost);
        setGameAnnouncement(`${player.name} đã Tới Nhất! Bạn về sau.`);
      }
      return;
    }

    advanceTurn(updatedPlayers, playerIdx);
  };

  // Pass turn
  const executePlayerPass = (playerIdx: number) => {
    const updatedPlayers = [...players];
    updatedPlayers[playerIdx].passed = true;
    advanceTurn(updatedPlayers, playerIdx);
  };

  // Advance turn
  const advanceTurn = (currentPlayers: PlayerSeat[], justActedIdx: number) => {
    const activeContenders = currentPlayers.filter((p) => !p.passed && p.cards.length > 0);

    if (activeContenders.length <= 1) {
      const trickWinner = activeContenders[0] || currentPlayers[justActedIdx];
      const winnerIdx = currentPlayers.findIndex((p) => p.id === trickWinner.id);

      const resetPlayers = currentPlayers.map((p) => ({ ...p, passed: false }));
      setPlayers(resetPlayers);
      setLastPlay(null);
      setCurrentTurnIdx(winnerIdx);
      setGameAnnouncement(`Tròn vòng! ${resetPlayers[winnerIdx].name} bắt đầu vòng mới.`);
      return;
    }

    let nextIdx = (justActedIdx + 1) % 4;
    while (currentPlayers[nextIdx].passed || currentPlayers[nextIdx].cards.length === 0) {
      nextIdx = (nextIdx + 1) % 4;
    }

    setPlayers(currentPlayers);
    setCurrentTurnIdx(nextIdx);
  };

  // Active Turn Countdown Timer: Enforces turnTimeSeconds with auto-pass/auto-play on timeout
  useEffect(() => {
    if (gameState !== 'PLAYING') return;

    setTimerSeconds(turnTimeLimit);
    const interval = setInterval(() => {
      setTimerSeconds((prev) => {
        if (prev <= 1) {
          // Timeout reached
          if (currentTurnIdx === 0) {
            // Hero timeout
            if (lastPlay) {
              sounds.playFold();
              executePlayerPass(0);
            } else {
              // Leading turn: must play lowest single card
              const heroCards = [...players[0].cards].sort(compareTienLenCards);
              if (heroCards.length > 0) {
                executePlayerPlay(0, evaluateTienLenPlay([heroCards[0]]));
              }
            }
          }
          return turnTimeLimit;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [currentTurnIdx, gameState, turnTimeLimit, lastPlay, players]);

  // AI Bot Runner
  useEffect(() => {
    if (gameState !== 'PLAYING' || currentTurnIdx === 0) return;

    const bot = players[currentTurnIdx];
    if (bot.passed || bot.cards.length === 0) return;

    const thinkTime = 800 + Math.random() * 600;
    const timer = setTimeout(() => {
      const botCards = [...bot.cards].sort(compareTienLenCards);
      const targetPlay = lastPlay?.play || null;
      let chosenPlay: EvaluatedPlay | null = null;

      if (!targetPlay) {
        if (botCards.length >= 2 && botCards[0].rank === botCards[1].rank) {
          chosenPlay = evaluateTienLenPlay([botCards[0], botCards[1]]);
        } else {
          chosenPlay = evaluateTienLenPlay([botCards[0]]);
        }
      } else if (targetPlay.type === 'SINGLE') {
        for (const c of botCards) {
          const singlePlay = evaluateTienLenPlay([c]);
          if (canBeatTienLen(targetPlay, singlePlay)) {
            chosenPlay = singlePlay;
            break;
          }
        }
      } else if (targetPlay.type === 'PAIR') {
        for (let i = 0; i < botCards.length - 1; i++) {
          if (botCards[i].rank === botCards[i + 1].rank) {
            const pairPlay = evaluateTienLenPlay([botCards[i], botCards[i + 1]]);
            if (canBeatTienLen(targetPlay, pairPlay)) {
              chosenPlay = pairPlay;
              break;
            }
          }
        }
      }

      if (chosenPlay) {
        executePlayerPlay(currentTurnIdx, chosenPlay);
      } else {
        sounds.playFold();
        executePlayerPass(currentTurnIdx);
      }
    }, thinkTime);

    return () => clearTimeout(timer);
  }, [currentTurnIdx, gameState, lastPlay]);

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col justify-between select-none overflow-hidden font-sans">
      {/* Cybergame Top Header */}
      <header className="px-3 sm:px-8 py-2.5 bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-b border-rose-950/80 flex items-center justify-between backdrop-blur-md z-30">
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onExit}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 text-xs font-semibold transition-colors"
          >
            ← Sảnh Game
          </button>
          <div className="flex items-center gap-2">
            <span className="text-xl">♥</span>
            <span className="font-serif font-black text-rose-400 tracking-wider text-xs sm:text-base uppercase whitespace-nowrap">
              TIẾN LÊN MIỀN NAM CYBER
            </span>
          </div>

          {roomConfig && (
            <button
              onClick={() => {
                sounds.playClick();
                if (navigator.clipboard) {
                  navigator.clipboard.writeText(roomConfig.code);
                  setCopyToast(`Đã sao chép mã: ${roomConfig.code}`);
                  setTimeout(() => setCopyToast(null), 2500);
                }
              }}
              className="px-2.5 py-1 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-mono font-bold text-xs flex items-center gap-1 active:scale-95"
            >
              <span>#{roomConfig.code}</span>
              <span className="text-[10px] underline hidden xs:inline">Sao chép</span>
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 sm:gap-4 font-mono text-xs">
          <div className="px-3 py-1 rounded-xl bg-slate-900/90 border border-slate-800">
            <span className="text-slate-400">Bàn: </span>
            <span className="text-amber-300 font-bold">${stake}</span>
          </div>
          <div className="px-3.5 py-1 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center gap-1.5">
            <span className="text-slate-400">Ví: </span>
            <span className="text-emerald-400 font-bold text-sm tabular-nums">${chips.toLocaleString()}</span>
          </div>
        </div>
      </header>

      {/* Copy Toast */}
      {copyToast && (
        <div className="fixed top-12 left-1/2 -translate-x-1/2 z-50 px-4 py-1.5 rounded-xl bg-rose-500 text-white font-bold text-xs shadow-2xl animate-bounce">
          {copyToast}
        </div>
      )}

      {/* Special Dramatic Pop-Up Banner (Cybergame style) */}
      {specialEffectText && (
        <div className="fixed inset-0 z-50 pointer-events-none flex items-center justify-center animate-in zoom-in-50 duration-300">
          <div className="px-10 py-5 rounded-3xl bg-gradient-to-r from-amber-600 via-rose-600 to-amber-600 border-4 border-yellow-300 text-white font-black text-2xl sm:text-4xl tracking-wider uppercase shadow-[0_0_80px_rgba(244,63,94,0.9)] animate-pulse text-center">
            {specialEffectText}
          </div>
        </div>
      )}

      {/* Cybergame Felt Arena */}
      <main className="max-w-5xl w-full mx-auto p-2 sm:p-4 flex flex-col items-center justify-center flex-1 overflow-hidden relative">
        {gameState === 'IDLE' ? (
          /* Lobby Start Screen */
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/95 border-2 border-rose-500/60 text-center max-w-md shadow-2xl backdrop-blur-md">
            <div className="w-16 h-16 rounded-2xl bg-rose-950 border border-rose-500/50 text-rose-400 flex items-center justify-center text-3xl mx-auto mb-3 shadow-lg">
              ♥
            </div>
            <h2 className="text-xl sm:text-2xl font-black font-serif text-white mb-2">
              Sới Bạc Tiến Lên Cyber
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed mb-6">
              Đồ họa sắc nét, bài sáng rõ cực kỳ dễ nhìn, hỗ trợ gợi ý nước đi, chặt heo và âm thanh sống động.
            </p>

            <div className="flex items-center justify-center gap-2 mb-6">
              <span className="text-xs text-slate-400 font-semibold uppercase">Mức Cược:</span>
              {[25, 50, 100, 200].map((amt) => (
                <button
                  key={amt}
                  onClick={() => setStake(amt)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-mono font-bold border transition-all ${
                    stake === amt
                      ? 'bg-rose-600 text-white border-rose-400 shadow-md scale-105'
                      : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
                  }`}
                >
                  ${amt}
                </button>
              ))}
            </div>

            <button
              onClick={startNewTienLen}
              className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-rose-600 via-red-500 to-rose-600 hover:from-rose-500 text-white font-black text-sm uppercase tracking-wider shadow-xl shadow-rose-600/30 active:scale-95 transition-all"
            >
              VÀO BÀN CHƠI NGAY (${stake})
            </button>
          </div>
        ) : (
          /* Active Cybergame Table */
          <div className="relative w-full min-h-[480px] sm:min-h-0 aspect-[4/5] sm:aspect-[16/11] max-h-[640px] rounded-[60px] sm:rounded-[200px] bg-gradient-to-b from-[#2e0912] via-[#120306] to-[#2e0912] border-[8px] sm:border-[18px] border-[#20090e] shadow-[0_30px_70px_rgba(0,0,0,0.95)] ring-2 sm:ring-4 ring-black/90 p-2 sm:p-6 flex flex-col justify-between items-center overflow-hidden">
            {/* Cybergame Felt Laser Ring */}
            <div className="absolute inset-2 sm:inset-5 rounded-[50px] sm:rounded-[180px] border border-rose-500/25 pointer-events-none shadow-inner" />

            {/* SEAT 2: TOP BOT (Nam Phong) */}
            <div className="relative z-10 flex flex-col items-center">
              <div
                className={`relative px-2.5 sm:px-3.5 py-0.5 sm:py-1 rounded-full text-[11px] sm:text-xs font-bold border backdrop-blur-md flex items-center gap-1.5 sm:gap-2 transition-all ${
                  currentTurnIdx === 2
                    ? 'bg-amber-500 text-slate-950 border-yellow-200 ring-4 ring-amber-400/80 shadow-xl scale-105'
                    : 'bg-slate-950/90 text-slate-200 border-slate-700'
                }`}
              >
                <div
                  className="w-4 h-4 sm:w-5 sm:h-5 rounded-full flex items-center justify-center text-[9px] sm:text-[10px] font-black text-white shadow"
                  style={{ backgroundColor: players[2].avatarColor }}
                >
                  {players[2].name.charAt(0)}
                </div>
                <span>{players[2].name}</span>
                <span className="font-mono text-[10px] sm:text-[11px] text-amber-200 font-bold">({players[2].cards.length} lá)</span>
                {currentTurnIdx === 2 && (
                  <span className="w-4 h-4 sm:w-5 sm:h-5 rounded-full bg-slate-950 text-amber-300 font-mono text-[10px] sm:text-[11px] font-bold flex items-center justify-center">
                    {timerSeconds}
                  </span>
                )}
                {players[2].cards.length === 1 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[8px] sm:text-[9px] font-black animate-pulse">
                    ⚠️ 1 LÁ!
                  </span>
                )}
                {players[2].passed && (
                  <span className="px-1.5 py-0.2 rounded bg-slate-800 text-slate-400 text-[8px] sm:text-[9px]">
                    BỎ LƯỢT
                  </span>
                )}
              </div>

              {/* Bot 2 Cards */}
              <div className="flex -space-x-3.5 mt-1">
                {players[2].cards.slice(0, 8).map((_, i) => (
                  <div key={i} className="transform hover:-translate-y-1 transition-transform">
                    <CardView faceDown size="xs" className="sm:hidden" />
                    <CardView faceDown size="sm" className="hidden sm:block" />
                  </div>
                ))}
              </div>
            </div>

            {/* MIDDLE ROW: SEAT 1 (Left), TABLE CENTER (Played Cards), SEAT 3 (Right) */}
            <div className="w-full flex items-center justify-between px-1 sm:px-10 z-10">
              {/* Left Bot: Dong Hai */}
              <div className="flex flex-col items-center max-w-[85px] sm:max-w-none">
                <div
                  className={`relative px-2 sm:px-3 py-0.5 sm:py-1 rounded-full text-[10px] sm:text-xs font-bold border backdrop-blur-md flex items-center gap-1 sm:gap-1.5 transition-all ${
                    currentTurnIdx === 1
                      ? 'bg-amber-500 text-slate-950 border-yellow-200 ring-2 sm:ring-4 ring-amber-400/80 shadow-xl scale-105'
                      : 'bg-slate-950/90 text-slate-200 border-slate-700'
                  }`}
                >
                  <div
                    className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full flex items-center justify-center text-[8px] sm:text-[9px] font-bold text-white shadow shrink-0"
                    style={{ backgroundColor: players[1].avatarColor }}
                  >
                    {players[1].name.charAt(0)}
                  </div>
                  <span className="truncate max-w-[45px] sm:max-w-none">{players[1].name}</span>
                  <span className="font-mono text-[10px] text-amber-200">({players[1].cards.length})</span>
                  {currentTurnIdx === 1 && (
                    <span className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-slate-950 text-amber-300 font-mono text-[9px] sm:text-[10px] flex items-center justify-center font-bold">
                      {timerSeconds}
                    </span>
                  )}
                </div>
                {players[1].cards.length === 1 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[8px] font-black animate-pulse mt-0.5">
                    ⚠️ 1 LÁ!
                  </span>
                )}
                {players[1].passed && (
                  <span className="text-[9px] text-slate-400 italic mt-0.5">Bỏ lượt</span>
                )}
                <div className="flex -space-x-3 mt-1">
                  {players[1].cards.slice(0, 5).map((_, i) => (
                    <React.Fragment key={i}>
                      <CardView faceDown size="xs" className="sm:hidden" />
                      <CardView faceDown size="sm" className="hidden sm:block" />
                    </React.Fragment>
                  ))}
                </div>
              </div>

              {/* TABLE CENTER: Cybergame Drop Zone with card slap depth */}
              <div className="flex flex-col items-center justify-center p-2 sm:p-5 rounded-2xl sm:rounded-3xl bg-black/75 border-2 border-rose-500/40 shadow-[0_0_50px_rgba(0,0,0,0.85)] min-w-[155px] sm:min-w-[260px] min-h-[110px] sm:min-h-[145px] backdrop-blur-md mx-1">
                {lastPlay ? (
                  <div className="flex flex-col items-center animate-in zoom-in-95 duration-200">
                    <div className="flex items-center gap-1.5 mb-1.5 flex-wrap justify-center">
                      <span className="text-[9px] sm:text-xs font-black uppercase text-amber-300 tracking-wider">
                        {players[lastPlay.playerIdx].name}
                      </span>
                      <span className="text-[9px] font-bold px-1.5 py-0.2 sm:px-2 sm:py-0.5 rounded-full bg-rose-950/80 text-rose-300 border border-rose-600/60 shadow">
                        {getTienLenPlayNameVi(lastPlay.play)}
                      </span>
                    </div>
                    <div
                      className="flex items-center -space-x-3 sm:-space-x-4 transition-transform duration-300 drop-shadow-[0_12px_24px_rgba(0,0,0,0.8)]"
                      style={{ transform: `rotate(${lastPlay.angle}deg)` }}
                    >
                      {lastPlay.play.cards.map((c) => (
                        <div key={c.id} className="shadow-2xl">
                          <CardView
                            card={c}
                            size="md"
                            twoColor={true}
                            showHeoBadge={true}
                            className="shadow-2xl"
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center text-center text-rose-300/50">
                    <span className="text-2xl sm:text-3xl text-rose-400/60">♠ ♥ ♦ ♣</span>
                    <span className="text-[10px] sm:text-xs font-serif italic mt-1 font-bold text-amber-300/80">
                      VÒNG MỚI · ĐÁNH TỰ DO
                    </span>
                  </div>
                )}
              </div>

              {/* Right Bot: Tay Son */}
              <div className="flex flex-col items-center max-w-[85px] sm:max-w-none">
                <div
                  className={`relative px-2 sm:px-3 py-0.5 sm:py-1 rounded-full text-[10px] sm:text-xs font-bold border backdrop-blur-md flex items-center gap-1 sm:gap-1.5 transition-all ${
                    currentTurnIdx === 3
                      ? 'bg-amber-500 text-slate-950 border-yellow-200 ring-2 sm:ring-4 ring-amber-400/80 shadow-xl scale-105'
                      : 'bg-slate-950/90 text-slate-200 border-slate-700'
                  }`}
                >
                  <div
                    className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full flex items-center justify-center text-[8px] sm:text-[9px] font-bold text-white shadow shrink-0"
                    style={{ backgroundColor: players[3].avatarColor }}
                  >
                    {players[3].name.charAt(0)}
                  </div>
                  <span className="truncate max-w-[45px] sm:max-w-none">{players[3].name}</span>
                  <span className="font-mono text-[10px] text-amber-200">({players[3].cards.length})</span>
                  {currentTurnIdx === 3 && (
                    <span className="w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-slate-950 text-amber-300 font-mono text-[9px] sm:text-[10px] flex items-center justify-center font-bold">
                      {timerSeconds}
                    </span>
                  )}
                </div>
                {players[3].cards.length === 1 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-rose-600 text-white text-[8px] font-black animate-pulse mt-0.5">
                    ⚠️ 1 LÁ!
                  </span>
                )}
                {players[3].passed && (
                  <span className="text-[9px] text-slate-400 italic mt-0.5">Bỏ lượt</span>
                )}
                <div className="flex -space-x-3 mt-1">
                  {players[3].cards.slice(0, 5).map((_, i) => (
                    <React.Fragment key={i}>
                      <CardView faceDown size="xs" className="sm:hidden" />
                      <CardView faceDown size="sm" className="hidden sm:block" />
                    </React.Fragment>
                  ))}
                </div>
              </div>
            </div>

            {/* SEAT 0: HERO (Bottom Hand with Super Bright Cards & Fanning) */}
            <div className="relative z-20 flex flex-col items-center w-full">
              {/* Turn Status Alert */}
              <div className="flex items-center gap-2 mb-2">
                <div
                  className={`px-4 py-1 rounded-full text-xs font-black uppercase tracking-wider border shadow-xl flex items-center gap-2 ${
                    currentTurnIdx === 0
                      ? 'bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 border-yellow-200 ring-4 ring-amber-400/80 animate-pulse'
                      : 'bg-slate-900/90 text-slate-300 border-slate-700'
                  }`}
                >
                  <span>{currentTurnIdx === 0 ? '★ LƯỢT CỦA BẠN ĐÁNH ★' : `Lượt của: ${players[currentTurnIdx].name}`}</span>
                  {currentTurnIdx === 0 && (
                    <span className="font-mono text-xs font-black bg-slate-950 text-amber-300 px-2 py-0.5 rounded-full">
                      {timerSeconds}s
                    </span>
                  )}
                </div>

                {players[0].cards.length === 1 && (
                  <span className="px-2.5 py-1 rounded-full bg-rose-600 text-white font-black text-xs animate-bounce shadow-lg">
                    ⚠️ BÁO 1 LÁ!
                  </span>
                )}
              </div>

              {/* HERO FANNED CARDS: High contrast, pure white, large clear font with Cybergame Curved Arc */}
              <div className="relative flex items-end justify-center -space-x-3.5 sm:-space-x-4 max-w-full px-1 sm:px-6 pt-6 sm:pt-10 pb-2 overflow-x-auto sm:overflow-visible scrollbar-none touch-pan-x">
                {players[0].cards.map((card, idx) => {
                  const isSelected = selectedCardIds.has(card.id);
                  const totalHeroCards = players[0].cards.length;
                  const centerIdx = (totalHeroCards - 1) / 2;
                  const offset = idx - centerIdx;
                  // Organic card fanning angle and arc
                  const rotationAngle = isSelected ? 0 : Math.max(-14, Math.min(14, offset * 2.2));
                  const verticalArc = isSelected ? -32 : Math.abs(offset) * 1.4;

                  return (
                    <div
                      key={card.id}
                      onMouseDown={(e) => {
                        e.preventDefault();
                        handleCardMouseDown(card.id);
                      }}
                      onMouseEnter={() => handleCardMouseEnter(card.id)}
                      onTouchStart={(e) => {
                        handleCardMouseDown(card.id);
                      }}
                      onDoubleClick={() => handleDoubleClickCard(card)}
                      style={{
                        transform: `translateY(${verticalArc}px) rotate(${rotationAngle}deg)`,
                      }}
                      className={`cursor-pointer transition-all duration-150 select-none shrink-0 ${
                        isSelected
                          ? 'scale-110 z-40 drop-shadow-[0_20px_35px_rgba(251,191,36,0.85)]'
                          : 'hover:-translate-y-6 hover:scale-105 hover:z-30 hover:rotate-0'
                      }`}
                      title="Chạm để chọn / Giữ chuột lướt qua để chọn nhiều lá / Nhấp đúp để gom bộ"
                    >
                      <CardView
                        card={card}
                        highlight={isSelected}
                        size="lg"
                        twoColor={true}
                        showHeoBadge={true}
                        className="shadow-2xl"
                      />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Cybergame Action Bar with Quick Tools */}
        {gameState === 'PLAYING' && (
          <div className="w-full max-w-xl mt-2 sm:mt-3 flex flex-wrap sm:flex-nowrap items-center justify-between gap-1.5 sm:gap-2 p-2 sm:p-3 bg-slate-900/95 border border-slate-800 rounded-2xl shadow-2xl backdrop-blur-md">
            {/* Utility Tools */}
            <div className="flex items-center gap-1 sm:gap-1.5 w-full sm:w-auto justify-between sm:justify-start">
              <button
                onClick={handleSortHand}
                className="flex-1 sm:flex-initial px-2.5 sm:px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-colors whitespace-nowrap text-center"
                title="Xếp bài từ 3 đến 2"
              >
                Xếp 🔀
              </button>

              <button
                onClick={handleSmartHint}
                disabled={currentTurnIdx !== 0}
                className="flex-1 sm:flex-initial px-2.5 sm:px-3 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-bold transition-colors disabled:opacity-40 whitespace-nowrap text-center"
                title="Tự động tìm nước bài đè"
              >
                Gợi Ý 💡
              </button>

              {selectedCardIds.size > 0 && (
                <button
                  onClick={handleDeselectAll}
                  className="px-2 sm:px-2.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 text-xs transition-colors whitespace-nowrap"
                >
                  Bỏ Chọn
                </button>
              )}
            </div>

            {/* Main Action Buttons */}
            <div className="flex items-center gap-1.5 sm:gap-2 w-full sm:w-auto">
              <button
                onClick={handleHeroPass}
                disabled={currentTurnIdx !== 0 || !lastPlay}
                className="flex-1 sm:flex-initial px-3.5 sm:px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-rose-950 hover:text-rose-300 disabled:opacity-40 text-slate-300 font-bold text-xs uppercase border border-slate-700 transition-colors whitespace-nowrap text-center"
              >
                BỎ LƯỢT
              </button>

              <button
                onClick={handleHeroPlayCards}
                disabled={!canPlaySelected}
                className="flex-1 sm:flex-initial px-4 sm:px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 via-yellow-400 to-amber-500 hover:from-amber-400 disabled:bg-slate-800 disabled:text-slate-600 text-slate-950 font-black text-xs sm:text-sm uppercase tracking-wider transition-all shadow-lg shadow-amber-500/25 active:scale-95 flex items-center justify-center gap-1 whitespace-nowrap"
              >
                <span>ĐÁNH BÀI</span>
                {selectedCardIds.size > 0 && <span>({selectedCardIds.size})</span>}
              </button>
            </div>
          </div>
        )}

        {/* Game Over Screen */}
        {gameState === 'GAME_OVER' && (
          <div className="mt-4">
            <button
              onClick={startNewTienLen}
              className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-rose-600 via-red-500 to-rose-600 hover:from-rose-500 text-white font-black text-sm uppercase tracking-wider shadow-xl shadow-rose-600/30 active:scale-95 transition-all"
            >
              CHƠI TIẾP VÁN MỚI
            </button>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="p-2.5 bg-slate-950 border-t border-slate-900 text-center text-xs text-slate-500">
        Tiến Lên Miền Nam Cyber · 2 Cơ lớn nhất · Chạm đúp vào lá bài để gom bộ · Bấm Gợi Ý để tự động chọn bài đè
      </footer>
    </div>
  );
};
