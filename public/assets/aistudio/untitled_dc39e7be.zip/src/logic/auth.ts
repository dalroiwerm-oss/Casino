/**
 * Authentication and User Role Management
 * Supports Player Name Quick-Registration, Profile Details, Stats, and Admin Login.
 */

export interface UserProfile {
  id: string;
  name: string;
  chips: number;
  avatarColor: string;
  isAdmin: boolean;
  role: 'player' | 'admin';
  createdAt: string;
  lastDailyReward?: string;
  handsPlayed?: number;
  handsWon?: number;
  biggestPotWon?: number;
  bestHandNameVi?: string;
  tournamentTrophies?: number;
}

const STORAGE_KEY_USER = 'poker_hub_user_profile';
const STORAGE_KEY_CUSTOM_GAMES = 'poker_hub_custom_games';
const STORAGE_KEY_SYSTEM_SETTINGS = 'poker_hub_system_settings';

export interface SystemSettings {
  defaultStartingChips: number;
  maintenanceMode: boolean;
  allowGuestRebuy: boolean;
  maxRaiseMultiplier: number;
}

export const DEFAULT_SYSTEM_SETTINGS: SystemSettings = {
  defaultStartingChips: 2500,
  maintenanceMode: false,
  allowGuestRebuy: true,
  maxRaiseMultiplier: 10,
};

export function getStoredUser(): UserProfile | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_USER);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    const id = parsed.id || 'usr_' + (parsed.name || 'player').replace(/[^a-zA-Z0-9]/g, '_').toLowerCase();
    return {
      id,
      handsPlayed: 0,
      handsWon: 0,
      biggestPotWon: 0,
      bestHandNameVi: 'Chưa có',
      tournamentTrophies: 0,
      ...parsed,
    };
  } catch {
    return null;
  }
}

export function saveUser(profile: UserProfile): void {
  try {
    localStorage.setItem(STORAGE_KEY_USER, JSON.stringify(profile));
  } catch {
    // ignore
  }
}

export function clearUser(): void {
  try {
    localStorage.removeItem(STORAGE_KEY_USER);
  } catch {
    // ignore
  }
}

export function claimDailyReward(user: UserProfile): {
  success: boolean;
  reward: number;
  updatedUser: UserProfile;
  message: string;
} {
  const today = new Date().toDateString();
  if (user.lastDailyReward === today) {
    return {
      success: false,
      reward: 0,
      updatedUser: user,
      message: 'Bạn đã nhận quà điểm danh hôm nay rồi. Hãy quay lại vào ngày mai nhé!',
    };
  }

  const reward = 1000;
  const updatedUser: UserProfile = {
    ...user,
    chips: user.chips + reward,
    lastDailyReward: today,
  };

  saveUser(updatedUser);

  return {
    success: true,
    reward,
    updatedUser,
    message: `Chúc mừng! Bạn đã nhận thành công +$${reward.toLocaleString()} chip điểm danh hàng ngày!`,
  };
}

export function getStoredSystemSettings(): SystemSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SYSTEM_SETTINGS);
    if (!raw) return DEFAULT_SYSTEM_SETTINGS;
    return { ...DEFAULT_SYSTEM_SETTINGS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_SYSTEM_SETTINGS;
  }
}

export function saveSystemSettings(settings: SystemSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY_SYSTEM_SETTINGS, JSON.stringify(settings));
  } catch {
    // ignore
  }
}

/**
 * Checks Admin credentials
 * Admin username: admin, password: admin2112
 */
export function verifyAdminCredentials(user: string, pass: string): boolean {
  const trimmedUser = user.trim().toLowerCase();
  const trimmedPass = pass.trim();
  return trimmedUser === 'admin' && trimmedPass === 'admin2112';
}
