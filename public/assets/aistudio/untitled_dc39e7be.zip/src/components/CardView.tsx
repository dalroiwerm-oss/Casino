import React from 'react';
import { Card, RANK_LABELS, SUIT_SYMBOLS, Suit } from '../logic/poker';

interface CardViewProps {
  card?: Card;
  faceDown?: boolean;
  highlight?: boolean;
  dimmed?: boolean;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  peekable?: boolean;
  twoColor?: boolean; // If true: Hearts & Diamonds = Vivid Red, Spades & Clubs = Crisp Black
  showHeoBadge?: boolean; // Special badge for 2 (Heo) in Tien Len
}

export const CardView: React.FC<CardViewProps> = ({
  card,
  faceDown = false,
  highlight = false,
  dimmed = false,
  size = 'md',
  className = '',
  peekable = false,
  twoColor = false,
  showHeoBadge = true,
}) => {
  const isRed = card && (card.suit === 'hearts' || card.suit === 'diamonds');
  const isHeo = card && card.rank === 2;
  const isAce = card && card.rank === 14;

  const getSuitColor = (suit: Suit) => {
    if (twoColor) {
      return suit === 'hearts' || suit === 'diamonds'
        ? 'text-[#dc2626]' // Pure vibrant casino red
        : 'text-[#09090b]'; // Pitch rich carbon black
    }

    switch (suit) {
      case 'hearts':
        return 'text-[#dc2626]';
      case 'spades':
        return 'text-[#09090b]';
      case 'diamonds':
        return 'text-[#0284c7]';
      case 'clubs':
        return 'text-[#059669]';
    }
  };

  const sizeClasses = {
    xs: 'w-8 h-12 text-[10px] rounded sm:w-10 sm:h-14 sm:text-xs sm:rounded-md',
    sm: 'w-9 h-13 text-[10px] rounded-md sm:w-12 sm:h-17 sm:text-xs sm:rounded-lg',
    md: 'w-11 h-16 text-xs rounded-lg sm:w-16 sm:h-24 sm:text-sm sm:rounded-xl',
    lg: 'w-13 h-19 text-xs rounded-xl sm:w-20 sm:h-29 sm:text-base sm:rounded-2xl',
    xl: 'w-16 h-23 text-sm rounded-xl sm:w-24 sm:h-35 sm:text-lg sm:rounded-2xl',
  }[size];

  if (faceDown || !card) {
    return (
      <div
        className={`relative select-none aspect-[5/7] border-2 border-amber-400/60 shadow-[0_4px_14px_rgba(0,0,0,0.6)] overflow-hidden transition-all duration-200 ${sizeClasses} ${
          dimmed ? 'opacity-40 grayscale' : 'opacity-100'
        } ${className}`}
        style={{
          background: 'radial-gradient(circle at 50% 40%, #1e1b4b 0%, #090d16 80%, #030712 100%)',
        }}
      >
        {/* Luxury Cybergame Card Back Pattern */}
        <div className="absolute inset-1 border border-amber-400/40 rounded-[inherit] flex items-center justify-center overflow-hidden">
          <svg className="w-full h-full opacity-50" viewBox="0 0 40 56">
            <defs>
              <pattern id="cardPatternBackCyber" width="8" height="8" patternUnits="userSpaceOnUse">
                <path d="M4 0 L8 4 L4 8 L0 4 Z" fill="none" stroke="#f59e0b" strokeWidth="0.8" />
                <circle cx="4" cy="4" r="1.3" fill="#fbbf24" />
              </pattern>
            </defs>
            <rect width="40" height="56" fill="url(#cardPatternBackCyber)" />
          </svg>
          <div className="absolute w-7 h-7 rounded-full border-2 border-amber-300 bg-amber-950/90 flex items-center justify-center text-xs font-serif font-black text-amber-300 shadow-[0_0_12px_rgba(251,191,36,0.6)]">
            ♠
          </div>
        </div>
        {/* Gloss sheen across back */}
        <div className="absolute top-0 inset-x-0 h-1/2 bg-gradient-to-b from-white/15 to-transparent pointer-events-none" />
      </div>
    );
  }

  const suitSymbol = SUIT_SYMBOLS[card.suit];
  const suitColor = getSuitColor(card.suit);
  const rankLabel = RANK_LABELS[card.rank];

  return (
    <div
      className={`relative select-none bg-gradient-to-b from-[#ffffff] via-[#ffffff] to-[#f1f5f9] font-sans aspect-[5/7] transition-all duration-200 border-2 ${
        highlight
          ? 'border-amber-400 ring-4 ring-amber-400/90 shadow-[0_0_30px_rgba(251,191,36,0.9)] z-30'
          : 'border-slate-300 hover:border-amber-300 shadow-[0_4px_16px_rgba(0,0,0,0.45)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.6)]'
      } ${dimmed ? 'opacity-40 grayscale' : 'opacity-100'} ${
        peekable ? 'cursor-pointer hover:-translate-y-2.5' : ''
      } ${sizeClasses} ${className}`}
      style={{
        boxShadow: highlight
          ? '0 0 0 3px #fbbf24, 0 10px 25px -5px rgba(251,191,36,0.8), 0 8px 10px -6px rgba(0,0,0,0.5)'
          : '0 4px 14px rgba(0,0,0,0.35)',
      }}
    >
      {/* Top Left Corner */}
      <div className={`absolute top-1 left-1.5 leading-none font-black ${suitColor} flex flex-col items-center pointer-events-none`}>
        <span className="text-[14px] sm:text-[19px] font-black tracking-tight leading-none drop-shadow-xs">
          {rankLabel}
        </span>
        <span className="text-[12px] sm:text-[16px] -mt-0.5 leading-none">
          {suitSymbol}
        </span>
      </div>

      {/* Cybergame Heo / Ace Special Badge */}
      {showHeoBadge && isHeo && (
        <div className="absolute top-1 right-1 px-1 py-0.2 rounded bg-gradient-to-r from-amber-500 to-yellow-400 text-slate-950 font-black text-[8px] sm:text-[9px] uppercase tracking-tighter shadow-sm animate-pulse border border-amber-300 pointer-events-none">
          HEO
        </div>
      )}
      {showHeoBadge && isAce && !isHeo && (
        <div className="absolute top-1 right-1 px-1 py-0.2 rounded bg-slate-900 text-amber-300 font-black text-[8px] sm:text-[9px] uppercase tracking-tighter shadow-sm border border-slate-700 pointer-events-none">
          ÁT
        </div>
      )}

      {/* Center Large Suit Symbol with Depth */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <span
          className={`text-3xl sm:text-5xl font-serif ${suitColor} select-none drop-shadow-[0_2px_4px_rgba(0,0,0,0.12)] transition-transform duration-200 ${
            highlight ? 'scale-110' : ''
          }`}
          style={{ opacity: 0.96 }}
        >
          {suitSymbol}
        </span>
      </div>

      {/* Bottom Right Corner (Inverted) */}
      <div
        className={`absolute bottom-1 right-1.5 leading-none font-black ${suitColor} flex flex-col items-center rotate-180 pointer-events-none`}
      >
        <span className="text-[14px] sm:text-[19px] font-black tracking-tight leading-none drop-shadow-xs">
          {rankLabel}
        </span>
        <span className="text-[12px] sm:text-[16px] -mt-0.5 leading-none">
          {suitSymbol}
        </span>
      </div>

      {/* Bright Glass Reflection Overlays */}
      <div className="absolute inset-1 border border-white/80 rounded-[inherit] pointer-events-none" />
      <div className="absolute top-0 inset-x-0 h-2/5 bg-gradient-to-b from-white/90 via-white/30 to-transparent rounded-t-[inherit] pointer-events-none" />

      {/* Highlight Top Glow Line */}
      {highlight && (
        <div className="absolute top-0 inset-x-0 h-1 bg-amber-300 rounded-t-[inherit] animate-pulse" />
      )}
    </div>
  );
};
