import React, { useState } from 'react';
import { GameDefinition, loadCurrentGames, saveCurrentGames, resetDefaultGames } from '../games/registry';
import { UserProfile, SystemSettings, getStoredSystemSettings, saveSystemSettings, clearUser } from '../logic/auth';
import { sounds } from '../logic/audio';

interface AdminDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onLogoutAdmin: () => void;
  onGamesUpdated: (games: GameDefinition[]) => void;
  onUserUpdated: (user: UserProfile) => void;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLogoutAdmin,
  onGamesUpdated,
  onUserUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'games' | 'chips' | 'settings'>('games');
  const [games, setGames] = useState<GameDefinition[]>(() => loadCurrentGames());
  const [settings, setSettings] = useState<SystemSettings>(() => getStoredSystemSettings());

  // Form for adding a new game
  const [newGameTitle, setNewGameTitle] = useState<string>('');
  const [newGameSubtitle, setNewGameSubtitle] = useState<string>('');
  const [newGameCategory, setNewGameCategory] = useState<'cards' | 'casino' | 'lottery'>('cards');
  const [newGameIcon, setNewGameIcon] = useState<string>('🎲');
  const [newGameDesc, setNewGameDesc] = useState<string>('');
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [notification, setNotification] = useState<string>('');

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(''), 3000);
  };

  // Toggle game availability status
  const handleToggleStatus = (gameId: string) => {
    sounds.playClick();
    const updated = games.map((g) => {
      if (g.id !== gameId) return g;
      const nextStatus = g.status === 'available' ? 'coming_soon' : 'available';
      const nextBadge = nextStatus === 'available' ? 'ĐANG MỞ' : 'CẬP NHẬT SAU';
      return {
        ...g,
        status: nextStatus as 'available' | 'coming_soon',
        badge: nextBadge,
      };
    });
    setGames(updated);
    saveCurrentGames(updated);
    onGamesUpdated(updated);
    showToast('Đã cập nhật trạng thái trò chơi!');
  };

  // Reset games to default
  const handleResetGames = () => {
    sounds.playClick();
    const defaults = resetDefaultGames();
    setGames(defaults);
    onGamesUpdated(defaults);
    showToast('Đã khôi phục danh sách trò chơi mặc định!');
  };

  // Add new game to registry
  const handleAddNewGame = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGameTitle.trim()) return;

    const newId = `custom_${Date.now()}`;
    const newGame: GameDefinition = {
      id: newId,
      title: newGameTitle.trim(),
      subtitle: newGameSubtitle.trim() || 'Trò Chơi Mới',
      category: newGameCategory,
      categoryLabelVi: newGameCategory === 'cards' ? 'Game Bài' : newGameCategory === 'casino' ? 'Casino' : 'Vé Số',
      descriptionVi: newGameDesc.trim() || 'Trò chơi mới được thêm vào từ bảng điều khiển quản trị.',
      playersCount: 'Nhiều người chơi',
      difficulty: 'Dễ',
      status: 'coming_soon',
      badge: 'CẬP NHẬT SAU',
      icon: newGameIcon || '🎮',
      gradient: 'from-slate-900 via-slate-950 to-slate-950',
      borderHover: 'hover:border-cyan-400',
      accentColor: '#06b6d4',
      tags: ['Mới Thêm', 'Quản Trị'],
    };

    const updated = [...games, newGame];
    setGames(updated);
    saveCurrentGames(updated);
    onGamesUpdated(updated);

    // Reset form
    setNewGameTitle('');
    setNewGameSubtitle('');
    setNewGameDesc('');
    setShowAddForm(false);
    sounds.playWin();
    showToast(`Đã thêm trò chơi "${newGame.title}" vào danh sách!`);
  };

  // Give chips to player / admin
  const handleGiveChips = (amount: number) => {
    sounds.playChips();
    const updated: UserProfile = {
      ...currentUser,
      chips: currentUser.chips + amount,
    };
    onUserUpdated(updated);
    showToast(`Đã cộng +$${amount.toLocaleString()} chip thành công!`);
  };

  // Save system settings
  const handleUpdateSettings = (newSettings: SystemSettings) => {
    setSettings(newSettings);
    saveSystemSettings(newSettings);
    showToast('Đã lưu cấu hình hệ thống!');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-in fade-in select-none">
      <div className="relative w-full max-w-3xl max-h-[90vh] bg-slate-900 border-2 border-rose-500/70 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-white">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-3">
            <span className="w-8 h-8 rounded-lg bg-rose-950 border border-rose-500/60 text-rose-400 flex items-center justify-center text-sm font-bold">
              🛡️
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white font-serif">
                  Bảng Điều Khiển Quản Trị (Admin)
                </h2>
                <span className="text-[10px] px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-700 font-mono font-bold">
                  SUPERUSER
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Toàn quyền quản lý danh sách trò chơi, cấp phát chip và cấu hình hệ thống
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center text-xs font-bold transition-colors"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 px-5 py-2.5 bg-slate-950/60 border-b border-slate-800 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('games')}
            className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap min-h-[36px] ${
              activeTab === 'games'
                ? 'bg-rose-600 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Quản Lý Trò Chơi ({games.length})
          </button>
          <button
            onClick={() => setActiveTab('chips')}
            className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap min-h-[36px] ${
              activeTab === 'chips'
                ? 'bg-rose-600 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Cấp Chip & Tài Khoản
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-colors whitespace-nowrap min-h-[36px] ${
              activeTab === 'settings'
                ? 'bg-rose-600 text-white shadow'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            Cấu Hình Hệ Thống
          </button>
        </div>

        {/* Toast Notification */}
        {notification && (
          <div className="px-5 py-2 bg-emerald-950 border-b border-emerald-700 text-emerald-300 text-xs font-semibold flex items-center gap-2 animate-in slide-in-from-top">
            <span>✓</span>
            <span>{notification}</span>
          </div>
        )}

        {/* Tab 1: Quản lý trò chơi */}
        {activeTab === 'games' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs text-slate-400 font-medium">
                Bật/tắt trạng thái hiển thị của các trò chơi trong sảnh chính:
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowAddForm(!showAddForm)}
                  className="px-3 py-1.5 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-xs font-bold transition-colors whitespace-nowrap"
                >
                  {showAddForm ? 'Hủy Thêm' : '+ Thêm Trò Chơi Mới'}
                </button>
                <button
                  onClick={handleResetGames}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium transition-colors whitespace-nowrap"
                >
                  Mặc Định
                </button>
              </div>
            </div>

            {/* Add New Game Form Drawer */}
            {showAddForm && (
              <form onSubmit={handleAddNewGame} className="p-4 rounded-xl bg-slate-950 border border-amber-500/50 space-y-3">
                <div className="font-bold text-xs text-amber-300 uppercase tracking-wider">
                  Thêm Tựa Game Mới Vào Sảnh:
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Tên Trò Chơi:</label>
                    <input
                      type="text"
                      placeholder="VD: Xóc Đĩa, Bầu Cua, Liêng..."
                      value={newGameTitle}
                      onChange={(e) => setNewGameTitle(e.target.value)}
                      required
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Mô Tả Phụ (Subtitle):</label>
                    <input
                      type="text"
                      placeholder="VD: Dân Gian Truyền Thống"
                      value={newGameSubtitle}
                      onChange={(e) => setNewGameSubtitle(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Danh Mục:</label>
                    <select
                      value={newGameCategory}
                      onChange={(e) => setNewGameCategory(e.target.value as any)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                    >
                      <option value="cards">Game Bài</option>
                      <option value="casino">Casino & Quay Hũ</option>
                      <option value="lottery">Vé Số & Cào</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">Biểu Tượng (Icon Emoji):</label>
                    <input
                      type="text"
                      value={newGameIcon}
                      onChange={(e) => setNewGameIcon(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Mô Tả Trò Chơi:</label>
                  <textarea
                    rows={2}
                    placeholder="Mô tả tóm tắt luật chơi..."
                    value={newGameDesc}
                    onChange={(e) => setNewGameDesc(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700 text-xs text-white"
                  />
                </div>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
                >
                  Xác Nhận Thêm Game
                </button>
              </form>
            )}

            {/* Games List Table */}
            <div className="space-y-2">
              {games.map((game) => (
                <div
                  key={game.id}
                  className="flex items-center justify-between gap-3 p-3 rounded-xl bg-slate-950/70 border border-slate-800 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-xl shrink-0">
                      {game.icon}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{game.title}</span>
                        <span className="text-xs text-slate-400 font-mono">({game.subtitle})</span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5">
                        <span>{game.categoryLabelVi}</span>
                        <span>·</span>
                        <span>{game.playersCount}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase font-bold ${
                        game.status === 'available'
                          ? 'bg-emerald-950/80 text-emerald-400 border-emerald-700'
                          : 'bg-amber-950/80 text-amber-300 border-amber-700'
                      }`}
                    >
                      {game.badge || (game.status === 'available' ? 'ĐANG MỞ' : 'CẬP NHẬT SAU')}
                    </span>

                    <button
                      onClick={() => handleToggleStatus(game.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all min-h-[36px] ${
                        game.status === 'available'
                          ? 'bg-slate-800 hover:bg-amber-950 hover:text-amber-300 text-slate-300 border border-slate-700'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow'
                      }`}
                    >
                      {game.status === 'available' ? 'Tắt Mở' : 'Kích Hoạt'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 2: Cấp Chip & Người chơi */}
        {activeTab === 'chips' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-400 uppercase tracking-wider font-bold">
                  Tài khoản đang đăng nhập:
                </span>
                <div className="text-base font-bold text-white mt-0.5">
                  {currentUser.name}
                </div>
                <div className="text-xs text-emerald-400 font-mono font-bold mt-0.5">
                  Số dư hiện tại: ${currentUser.chips.toLocaleString()}
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleGiveChips(10000)}
                  className="px-3 py-1.5 rounded-lg bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700 text-emerald-300 text-xs font-bold transition-colors"
                >
                  + $10,000
                </button>
                <button
                  onClick={() => handleGiveChips(50000)}
                  className="px-3 py-1.5 rounded-lg bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700 text-emerald-300 text-xs font-bold transition-colors"
                >
                  + $50,000
                </button>
                <button
                  onClick={() => handleGiveChips(500000)}
                  className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black transition-colors shadow"
                >
                  + $500,000 (VIP)
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                Cấu Hình Số Dư Người Chơi Mới Đăng Ký:
              </h3>
              <div className="grid grid-cols-3 gap-3">
                {[1000, 2500, 10000].map((amount) => (
                  <button
                    key={amount}
                    onClick={() => handleUpdateSettings({ ...settings, defaultStartingChips: amount })}
                    className={`p-3 rounded-xl border text-center transition-all ${
                      settings.defaultStartingChips === amount
                        ? 'bg-amber-500/10 border-amber-400 text-amber-300 ring-1 ring-amber-400'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="text-xs text-slate-400">Vốn khởi nghiệp:</div>
                    <div className="text-sm font-mono font-bold text-emerald-400 mt-0.5">
                      ${amount.toLocaleString()}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Cấu hình hệ thống */}
        {activeTab === 'settings' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-bold text-white">Cho phép nạp lại chip khi hết (Rebuy)</div>
                  <div className="text-xs text-slate-400">Người chơi hết chip trong bàn Cash có thể nạp lại tức thì</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.allowGuestRebuy}
                  onChange={(e) => handleUpdateSettings({ ...settings, allowGuestRebuy: e.target.checked })}
                  className="w-5 h-5 rounded bg-slate-900 border-slate-700 text-amber-500"
                />
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                <div>
                  <div className="text-sm font-bold text-white">Chế độ bảo trì hệ thống</div>
                  <div className="text-xs text-slate-400">Tạm thời thông báo bảo trì cho người chơi thông thường</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.maintenanceMode}
                  onChange={(e) => handleUpdateSettings({ ...settings, maintenanceMode: e.target.checked })}
                  className="w-5 h-5 rounded bg-slate-900 border-slate-700 text-rose-500"
                />
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="px-5 py-3.5 bg-slate-950 border-t border-slate-800 flex items-center justify-between">
          <button
            onClick={() => {
              sounds.playFold();
              onLogoutAdmin();
              onClose();
            }}
            className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 hover:text-rose-300 text-slate-400 text-xs font-semibold transition-colors flex items-center gap-1.5"
          >
            <span>Đăng Xuất Admin</span>
          </button>

          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition-colors"
          >
            Đóng Bảng Quản Trị
          </button>
        </div>
      </div>
    </div>
  );
};
