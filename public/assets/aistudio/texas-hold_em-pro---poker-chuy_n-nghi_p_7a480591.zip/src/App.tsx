/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { GameMode, TableTheme } from './types/poker';
import { GameList } from './components/GameList';
import { TitleScreen } from './components/TitleScreen';
import { PokerGame } from './components/PokerGame';
import { HandRankingModal } from './components/HandRankingModal';
import { PlayerRegisterModal } from './components/PlayerRegisterModal';
import { PlayerProfileModal } from './components/PlayerProfileModal';
import { AdminLoginModal } from './components/AdminLoginModal';
import { AdminDashboardModal } from './components/AdminDashboardModal';
import { PokerRoomModal } from './components/PokerRoomModal';
import { UserProfile, getStoredUser, clearUser, saveUser } from './logic/auth';
import { PokerRoom } from './logic/room';
import { GameDefinition, loadCurrentGames } from './games/registry';

type AppScreen = 'GAME_LIST' | 'POKER_TITLE' | 'POKER_PLAYING';

export default function App() {
  // Screen Router
  const [screen, setScreen] = useState<AppScreen>('GAME_LIST');
  const [mode, setMode] = useState<GameMode>('CASH');
  const [theme, setTheme] = useState<TableTheme>('EMERALD');
  const [stakeTier, setStakeTier] = useState<number>(1); // Standard tier

  // User & Auth State
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => getStoredUser());

  // Modals
  const [isHandRankingsOpen, setIsHandRankingsOpen] = useState<boolean>(false);
  const [isPlayerRegisterOpen, setIsPlayerRegisterOpen] = useState<boolean>(false);
  const [isPlayerProfileOpen, setIsPlayerProfileOpen] = useState<boolean>(false);
  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState<boolean>(false);
  const [isAdminDashboardOpen, setIsAdminDashboardOpen] = useState<boolean>(false);
  const [isPokerRoomOpen, setIsPokerRoomOpen] = useState<boolean>(false);

  // Active Poker Room Configuration
  const [activeRoomConfig, setActiveRoomConfig] = useState<{
    roomId: string;
    roomCode: string;
    roomName: string;
    isHost: boolean;
    players: import('./logic/room').RoomPlayer[];
  } | null>(null);

  // Active Poker settings
  const [gameConfig, setGameConfig] = useState({
    mode: 'CASH' as GameMode,
    theme: 'EMERALD' as TableTheme,
    smallBlind: 25,
    bigBlind: 50,
    initialChips: 2500,
  });

  // Keep user state in sync
  useEffect(() => {
    const stored = getStoredUser();
    if (stored) setCurrentUser(stored);
  }, []);

  const handleSelectGame = (gameId: string) => {
    if (gameId === 'poker') {
      // If user hasn't registered name yet, prompt them gently (or let them proceed)
      if (!currentUser) {
        setIsPlayerRegisterOpen(true);
      }
      setScreen('POKER_TITLE');
    }
  };

  const handleStartGame = (config: {
    mode: GameMode;
    theme: TableTheme;
    smallBlind: number;
    bigBlind: number;
    initialChips: number;
  }) => {
    setActiveRoomConfig(null);
    setGameConfig(config);
    setScreen('POKER_PLAYING');
  };

  const handleOpenPokerRoom = () => {
    if (!currentUser) {
      setIsPlayerRegisterOpen(true);
    }
    setIsPokerRoomOpen(true);
  };

  const handleEnterGameWithRoom = (room: PokerRoom) => {
    setIsPokerRoomOpen(false);
    setActiveRoomConfig({
      roomId: room.id,
      roomCode: room.code,
      roomName: room.name,
      isHost: room.hostId === (currentUser?.id || ''),
      players: room.players,
    });
    setGameConfig({
      mode: 'ROOM',
      theme,
      smallBlind: room.smallBlind,
      bigBlind: room.bigBlind,
      initialChips: room.buyIn,
    });
    setScreen('POKER_PLAYING');
  };

  const handleExitToPokerTitle = () => {
    setActiveRoomConfig(null);
    setScreen('POKER_TITLE');
  };

  const handleBackToGameList = () => {
    setActiveRoomConfig(null);
    setScreen('GAME_LIST');
  };

  // Auth Handlers
  const handleUserSaved = (user: UserProfile) => {
    setCurrentUser(user);
    saveUser(user);
  };

  const handleAdminLoggedIn = (adminUser: UserProfile) => {
    setCurrentUser(adminUser);
    saveUser(adminUser);
    setIsAdminDashboardOpen(true);
  };

  const handleLogoutAdmin = () => {
    clearUser();
    setCurrentUser(null);
  };

  const handlePokerStatsUpdate = (
    newChips: number,
    isWin: boolean,
    potSize: number,
    isTournamentWin?: boolean
  ) => {
    if (!currentUser) return;
    const updated: UserProfile = {
      ...currentUser,
      chips: newChips,
      handsPlayed: (currentUser.handsPlayed || 0) + 1,
      handsWon: (currentUser.handsWon || 0) + (isWin ? 1 : 0),
      biggestPotWon: Math.max(currentUser.biggestPotWon || 0, potSize),
      tournamentTrophies: (currentUser.tournamentTrophies || 0) + (isTournamentWin ? 1 : 0),
    };
    setCurrentUser(updated);
    saveUser(updated);
  };

  return (
    <div className="w-full min-h-screen bg-slate-950 font-sans text-slate-100 overflow-x-hidden">
      {screen === 'GAME_LIST' && (
        <GameList
          onSelectGame={handleSelectGame}
          onOpenHandRankings={() => setIsHandRankingsOpen(true)}
          currentUser={currentUser}
          onOpenPlayerRegister={() => setIsPlayerRegisterOpen(true)}
          onOpenPlayerProfile={() => setIsPlayerProfileOpen(true)}
          onOpenAdminLogin={() => setIsAdminLoginOpen(true)}
          onOpenAdminDashboard={() => setIsAdminDashboardOpen(true)}
          onOpenPokerRoom={handleOpenPokerRoom}
        />
      )}

      {screen === 'POKER_TITLE' && (
        <TitleScreen
          onStartGame={handleStartGame}
          selectedMode={mode}
          setSelectedMode={setMode}
          selectedTheme={theme}
          setSelectedTheme={setTheme}
          stakeTier={stakeTier}
          setStakeTier={setStakeTier}
          onOpenHandRankings={() => setIsHandRankingsOpen(true)}
          onOpenRoomMode={handleOpenPokerRoom}
          onBackToGameList={handleBackToGameList}
        />
      )}

      {screen === 'POKER_PLAYING' && (
        <PokerGame
          mode={gameConfig.mode}
          theme={gameConfig.theme}
          initialSmallBlind={gameConfig.smallBlind}
          initialBigBlind={gameConfig.bigBlind}
          initialBuyIn={currentUser ? Math.max(gameConfig.initialChips, currentUser.chips) : gameConfig.initialChips}
          onExitToTitle={handleBackToGameList}
          heroName={currentUser?.name}
          heroAvatarColor={currentUser?.avatarColor}
          roomConfig={activeRoomConfig || undefined}
          onStatsUpdate={handlePokerStatsUpdate}
        />
      )}

      {/* Poker Room Mode Modal: Tạo Phòng & Tham Gia Phòng */}
      <PokerRoomModal
        isOpen={isPokerRoomOpen}
        onClose={() => setIsPokerRoomOpen(false)}
        currentUser={currentUser}
        onEnterGameWithRoom={handleEnterGameWithRoom}
        onRequireRegisterName={() => setIsPlayerRegisterOpen(true)}
      />

      {/* Global Hand Ranking Modal */}
      <HandRankingModal
        isOpen={isHandRankingsOpen}
        onClose={() => setIsHandRankingsOpen(false)}
      />

      {/* Player Registration Modal */}
      <PlayerRegisterModal
        isOpen={isPlayerRegisterOpen}
        onClose={() => setIsPlayerRegisterOpen(false)}
        currentUser={currentUser}
        onUserSaved={handleUserSaved}
        onSwitchToAdmin={() => {
          setIsPlayerRegisterOpen(false);
          setIsAdminLoginOpen(true);
        }}
      />

      {/* Dedicated Player Profile Modal */}
      {currentUser && (
        <PlayerProfileModal
          isOpen={isPlayerProfileOpen}
          onClose={() => setIsPlayerProfileOpen(false)}
          currentUser={currentUser}
          onUserUpdated={handleUserSaved}
          onOpenEditName={() => {
            setIsPlayerProfileOpen(false);
            setIsPlayerRegisterOpen(true);
          }}
          onLogout={() => {
            clearUser();
            setCurrentUser(null);
            setIsPlayerProfileOpen(false);
          }}
        />
      )}

      {/* Admin Login Modal */}
      <AdminLoginModal
        isOpen={isAdminLoginOpen}
        onClose={() => setIsAdminLoginOpen(false)}
        onAdminLoggedIn={handleAdminLoggedIn}
        onSwitchToPlayer={() => {
          setIsAdminLoginOpen(false);
          setIsPlayerRegisterOpen(true);
        }}
      />

      {/* Admin Dashboard Modal */}
      {currentUser?.isAdmin && (
        <AdminDashboardModal
          isOpen={isAdminDashboardOpen}
          onClose={() => setIsAdminDashboardOpen(false)}
          currentUser={currentUser}
          onLogoutAdmin={handleLogoutAdmin}
          onGamesUpdated={() => {
            // Triggers state reload in components
          }}
          onUserUpdated={handleUserSaved}
        />
      )}
    </div>
  );
}
