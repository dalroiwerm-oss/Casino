import React from 'react';
import { Card, RANK_LABELS, SUIT_SYMBOLS, Suit } from '../logic/poker';

interface CardViewProps {
  card?: Card;
  faceDown?: boolean;
  highlight?: boolean;
  dimmed?: boolean;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  peekable?: boolean;
}

export const CardView: React.FC<CardViewProps> = ({
  card,
  faceDown = false,
  highlight = false,
  dimmed = false,
  size = 'md',
  className = '',
  peekable = false,
}) => {
  // Pro 4-Color deck colors: Spades (Black), Hearts (Red), Diamonds (Blue), Clubs (Green)
  const getSuitColor = (suit: Suit) => {
    switch (suit) {
      case 'hearts':
        return 'text-rose-600';
      case 'spades':
        return 'text-slate-900';
      case 'diamonds':
        return 'text-blue-600';
      case 'clubs':
        return 'text-emerald-700';
    }
  };

  const sizeClasses = {
    sm: 'w-8 h-12 text-[10px] rounded-xs sm:w-10 sm:h-14 sm:text-xs sm:rounded-sm',
    md: 'w-11 h-16 text-xs rounded-sm sm:w-14 sm:h-20 sm:text-sm sm:rounded-md',
    lg: 'w-14 h-20 text-sm rounded-md sm:w-18 sm:h-26 sm:text-base sm:rounded-lg',
  }[size];

  if (faceDown || !card) {
    return (
      <div
        className={`relative select-none aspect-[5/7] border border-amber-500/40 shadow-md overflow-hidden ${sizeClasses} ${
          dimmed ? 'opacity-40 grayscale' : 'opacity-100'
        } ${className}`}
        style={{
          background: 'linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%)',
        }}
      >
        {/* Luxury Card Back Pattern */}
        <div className="absolute inset-1 border border-amber-400/30 rounded-xs flex items-center justify-center overflow-hidden">
          <svg className="w-full h-full opacity-35" viewBox="0 0 40 56">
            <defs>
              <pattern id="cardPattern" width="8" height="8" patternUnits="userSpaceOnUse">
                <path d="M4 0 L8 4 L4 8 L0 4 Z" fill="none" stroke="#f59e0b" strokeWidth="0.6" />
                <circle cx="4" cy="4" r="1" fill="#f59e0b" />
              </pattern>
            </defs>
            <rect width="40" height="56" fill="url(#cardPattern)" />
          </svg>
          <div className="absolute w-5 h-5 rounded-full border border-amber-400/60 bg-amber-950/60 flex items-center justify-center text-[8px] font-serif font-bold text-amber-300">
            ♠
          </div>
        </div>
      </div>
    );
  }

  const suitSymbol = SUIT_SYMBOLS[card.suit];
  const suitColor = getSuitColor(card.suit);
  const rankLabel = RANK_LABELS[card.rank];

  return (
    <div
      className={`relative select-none bg-white font-sans aspect-[5/7] transition-all duration-200 border ${
        highlight
          ? 'border-amber-400 ring-2 ring-amber-400/90 shadow-lg shadow-amber-400/30 -translate-y-1'
          : 'border-slate-300 shadow-md hover:-translate-y-0.5'
      } ${dimmed ? 'opacity-40 grayscale' : 'opacity-100'} ${
        peekable ? 'cursor-pointer hover:shadow-xl hover:-translate-y-2' : ''
      } ${sizeClasses} ${className}`}
    >
      {/* Top Left Corner */}
      <div className={`absolute top-0.5 left-1 leading-none font-bold ${suitColor} flex flex-col items-center`}>
        <span className="text-[11px] sm:text-[13px] tracking-tight">{rankLabel}</span>
        <span className="text-[10px] sm:text-[11px] -mt-0.5">{suitSymbol}</span>
      </div>

      {/* Center Suit Symbol or Face Emblem */}
      <div className="absolute inset-0 flex items-center justify-center">
        <span className={`text-xl sm:text-2xl font-serif ${suitColor} opacity-90 select-none`}>
          {suitSymbol}
        </span>
      </div>

      {/* Bottom Right Corner (Inverted) */}
      <div
        className={`absolute bottom-0.5 right-1 leading-none font-bold ${suitColor} flex flex-col items-center rotate-180`}
      >
        <span className="text-[11px] sm:text-[13px] tracking-tight">{rankLabel}</span>
        <span className="text-[10px] sm:text-[11px] -mt-0.5">{suitSymbol}</span>
      </div>

      {/* Subtle inner card border */}
      <div className="absolute inset-0.5 border border-slate-100 rounded-[inherit] pointer-events-none" />
    </div>
  );
};
